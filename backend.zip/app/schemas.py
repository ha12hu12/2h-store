from pydantic import BaseModel, ConfigDict
from datetime import datetime
from typing import Optional


#--------user schemas--------#
class UserCreate(BaseModel):
    username: str
    password: str
class UserOut(BaseModel):
    id: int
    username: str
    model_config = ConfigDict(from_attributes=True)

class UserOutMe(BaseModel):
    id: int
    money: float
    username: str
    model_config = ConfigDict(from_attributes=True)
class UserUpdateUsername(BaseModel):
    username:str

class UserUpdateMoney(BaseModel):
    money: int

class UserUpdatePassword(BaseModel):
    current_password:str
    new_password:str

#--------auth schemas--------#
class UserLogin(BaseModel):
    username: str
    password: str
class Payload(BaseModel):
    id: int



#--------product schemas--------#
class ProductCreate(BaseModel):
    product_name: str
    description: Optional[str] = "there is no description"
    amount: int
    price: float
    image_url: Optional[str] = None
    pledge_shares: Optional[dict] = None # {"hassan": 5, etc..}

class ProductOut(BaseModel):
    id: int
    product_name: str
    description: str
    amount: int
    image_url: Optional[str] = None 
    price: float
    pledge_shares: Optional[dict] = None # {"hassan": 5, etc..}
    owner: UserOut
    
class MyProductOut(BaseModel):
    id: int
    product_name: str
    description: Optional[str] = "there is no description"
    amount: int
    pledge_shares: Optional[dict] = None
    price: float
    image_url: Optional[str] = None


class ProductUpdate(BaseModel):
    product_name: Optional[str] = None
    description: Optional[str] = None
    amount: Optional[int] = None
    price: Optional[float] = None 
    pledge_shares: Optional[dict] = None
    image_url: Optional[str] = None  

#--------cart schemas--------#
class ChangePaid(BaseModel):
    cart_id: int
    status: bool

class CartOutPurchases(BaseModel):
    id: int
    product: ProductOut
    status: bool

class CartOutDebts(BaseModel):
    id: int
    buyer: UserOut
    product: ProductOut
    status: bool