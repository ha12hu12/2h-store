from app.routers import user, auth, product, cart

from fastapi import  FastAPI
from fastapi.middleware.cors import CORSMiddleware

twoH = FastAPI()

origins = ["http://localhost:5173", "https://2h-store-frontend.vercel.app"]

twoH.add_middleware(
    CORSMiddleware,
    allow_origins=origins, 
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@twoH.get("/")
def root():
    return "root"

twoH.include_router(user.router)
twoH.include_router(auth.router)
twoH.include_router(product.router)
twoH.include_router(cart.router)